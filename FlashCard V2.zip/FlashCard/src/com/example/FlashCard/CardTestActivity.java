package com.example.FlashCard;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import com.tekle.oss.android.animation.AnimationFactory;

public class CardTestActivity extends Activity {

	private TextView txtPages;
	public static LayoutInflater inflater;
	private ViewFlipper viewFlipper;
	private int count, count_correct_answer;
	private int len, icon_id, de_id, loc_id, id;
	private String[] loc_strings, translate_strings;
	private int[] resIds;
	private long time;
	DataBaseCountWordHelper db_count_word = new DataBaseCountWordHelper(CardTestActivity.this);



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.card_test);
		Intent intent = getIntent();
		icon_id = intent.getIntExtra("id_icon", 0);
		de_id = intent.getIntExtra("id_de", 0);
		loc_id = intent.getIntExtra("id_loc", 0);
		id = intent.getIntExtra("id", 0);
		TypedArray ar = getResources().obtainTypedArray(icon_id);
		len = ar.length();
		resIds = new int[len];
		for (int i = 0; i < len; i++)
			resIds[i] = ar.getResourceId(i, 0);
		ar.recycle();
		loc_strings = getResources().getStringArray(loc_id);
		translate_strings = getResources().getStringArray(de_id);

		inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipper);
		txtPages = (TextView) findViewById(R.id.pagetextView);

		count = 1;

		time = System.currentTimeMillis();
		View view = inflater.inflate(R.layout.card_path1, null);
		ImageView icon = (ImageView) view.findViewById(R.id.imageView);
		icon.setImageResource(resIds[0]);
		TextView loc_text = (TextView) view.findViewById(R.id.locWordTextView);
		loc_text.setText(loc_strings[0]);
		viewFlipper.addView(view);
		updateTextView();
		view = inflater.inflate(R.layout.card_path2, null);
		TextView translate_text = (TextView) view.findViewById(R.id.translateTextView);
		translate_text.setText(translate_strings[0]);
		viewFlipper.addView(view);
		updateTextView();
		count_correct_answer = 0;
		viewFlipper.setOnTouchListener(new View.OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {

				switch (event.getAction()) {
					case MotionEvent.ACTION_UP:
						if (count % 2 == 1) {
							count++;
							AnimationFactory.flipTransition(viewFlipper, AnimationFactory.FlipDirection.LEFT_RIGHT);
							updateTextView();
							return true;
						}
				}
				return true;
			}
		});
	}


	public void onClickButtonMenu(View v) {
		onBackPressed();
	}

	public void onClickButtonRepeat(View v) {
		Intent intent = new Intent(CardTestActivity.this, CardTestActivity.class);
		intent.putExtra("id_icon", icon_id);
		intent.putExtra("id_de", de_id);
		intent.putExtra("id_loc", loc_id);
		intent.putExtra("id", id);
		startActivity(intent);
	}

	public void onClickOk(View v) {
		count++;
		count_correct_answer++;
		if ((count - 1) / 2 == len) {
			last_page();
		} else {
			next_page();
			updateTextView();
		}

	}

	public void last_page() {
		count = 0;
		View view = inflater.inflate(R.layout.cardtest_end, null);
		TextView text = (TextView) view.findViewById(R.id.textView);
		text.setText(getResources().getText(R.string.time) + " : " + (float) ((System.currentTimeMillis() - time) / 10) / 100 +
				getResources().getText(R.string.seconds)+ " \n"
				+ getResources().getText(R.string.correct_answer) + " : " + count_correct_answer);
		viewFlipper.addView(view);
		viewFlipper.showNext();

		DataBaseCategoryHelper dbHelper = new DataBaseCategoryHelper(this,getResources().getStringArray(R.array.category_menu));
		SQLiteDatabase db;

		try {
			db = dbHelper.getWritableDatabase();
		}
		catch (SQLiteException ex){
			db = dbHelper.getReadableDatabase();
		}

		ContentValues cv = new ContentValues();
		int answer_percent = (int)((double)count_correct_answer / (double)len * 100);

		cv.put(DataBaseCategoryHelper.COUNT_COMPLETED,answer_percent);
		db.update(DataBaseCategoryHelper.TABLE_NAME,cv,"_id = ?",  new String[] { String.valueOf(id+1) });
	}

	public void onClickRemove(View v) {
		count++;
		if ((count - 1) / 2 == len) {
			last_page();
		} else {
			next_page();
			updateTextView();
		}
	}

	private void next_page() {
		if (viewFlipper.getChildCount() > 2) {
			viewFlipper.removeViewAt(0);
			viewFlipper.removeViewAt(0);
			System.gc();
		}
		View view = inflater.inflate(R.layout.card_path1, null);
		ImageView icon = (ImageView) view.findViewById(R.id.imageView);
		icon.setImageResource(resIds[count / 2]);
		TextView loc_text = (TextView) view.findViewById(R.id.locWordTextView);
		loc_text.setText(loc_strings[count / 2]);
		viewFlipper.addView(view);

		view = inflater.inflate(R.layout.card_path2, null);
		TextView translate_text = (TextView) view.findViewById(R.id.translateTextView);
		translate_text.setText(translate_strings[count / 2]);
		viewFlipper.addView(view);
		AnimationFactory.flipTransition(viewFlipper, AnimationFactory.FlipDirection.RIGHT_LEFT);

	}

	private void updateTextView() {
		String pages = String.format("%1$s/%2$s", (count + 1) / 2, len);
		txtPages.setText(pages);
	}

	private void updateCountWord() {
		SQLiteDatabase db;
		try {
			db = db_count_word.getWritableDatabase();
		}
		catch (SQLiteException ex){
			db = db_count_word.getReadableDatabase();
		}
		Cursor cursor = db.query(DataBaseCategoryHelper.TABLE_NAME,null,null,null,null,null,null);
		cursor.moveToFirst();
		int i =  cursor.getInt(cursor.getColumnIndex(DataBaseCountWordHelper.COUNT)) ;
		cursor.close();
		i++;
		ContentValues cv = new ContentValues();
		cv.put(DataBaseCountWordHelper.COUNT,i);
		db.update(DataBaseCountWordHelper.TABLE_NAME,cv,"_id = ?",  new String[] { "1" });

	}
}
