package com.example.FlashCard;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Alex on 26.12.13.
 */
public class DataBaseCountWordHelper extends SQLiteOpenHelper {

	public static final String TABLE_NAME = "count_word";
	public static final String COUNT = "count";
	public static final String DATABASE_NAME = "db_count_word";
	public DataBaseCountWordHelper(Context context) {
		super(context, DATABASE_NAME, null, 1);
	}

	@Override
	public void onCreate(SQLiteDatabase sqLiteDatabase) {
		sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME
				+ " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
				+ COUNT + " INTEGER);");
		sqLiteDatabase.execSQL("INSERT INTO "+TABLE_NAME + "("+ COUNT+") VALUES (0);");
	}

	@Override
	public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i2) {

	}
}
