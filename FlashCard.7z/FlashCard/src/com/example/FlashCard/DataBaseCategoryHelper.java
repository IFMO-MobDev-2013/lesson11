package com.example.FlashCard;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ResourceBundle;


public class DataBaseCategoryHelper extends SQLiteOpenHelper {
	public static final String DATABASE_NAME = "mydatabase.db";
	public static final String TABLE_NAME = "table_category";
	public static final String NAME_CATEGORY = "category";
	public static final String COUNT_COMPLETED = "completed";
	public static String [] category;

	public DataBaseCategoryHelper(Context context, String[] category) {
		super(context, DATABASE_NAME, null, 3);
		this.category = category;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE " + TABLE_NAME
				+ " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
				+ NAME_CATEGORY + " TEXT, " + COUNT_COMPLETED + " INTEGER);");
		for (int i = 0; i < category.length; i++)
			db.execSQL("INSERT INTO "+TABLE_NAME + "("+NAME_CATEGORY+", "+ COUNT_COMPLETED+") VALUES (\"" + category[i]+"\", 0);");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE " + TABLE_NAME);
		onCreate(db);
	}


}
