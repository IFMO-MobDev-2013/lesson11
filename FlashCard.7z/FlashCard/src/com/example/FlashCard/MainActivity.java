package com.example.FlashCard;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.yandex.metrica.Counter;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends Activity {

	DataBaseCategoryHelper dbHelper;
	ArrayList<HashMap<String, String>> myArrList = new ArrayList<HashMap<String, String>>();
	HashMap<String, String> map;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu);
		Counter.initialize(getApplicationContext());
		Counter.sharedInstance().setReportsEnabled(true);
		Counter.sharedInstance().setTrackLocationEnabled(true);
		Counter.sharedInstance().reportEvent("Start App");
		Counter.sharedInstance().sendEventsBuffer();
		ListView menu_list = (ListView) findViewById(R.id.listView);
		/*dbHelper = new DataBaseCategoryHelper(this,getResources().getStringArray(R.array.category_menu));
		SQLiteDatabase db;

		try {
			db = dbHelper.getWritableDatabase();
		}
		catch (SQLiteException ex){
			db = dbHelper.getReadableDatabase();
		}


		Cursor cursor = db.query(DataBaseCategoryHelper.TABLE_NAME,null,null,null,null,null,null);
		while (cursor.moveToNext()) {
			String s = cursor.getString(cursor.getColumnIndex(DataBaseCategoryHelper.NAME_CATEGORY)) ;
			int i =  cursor.getInt(cursor.getColumnIndex(DataBaseCategoryHelper.COUNT_COMPLETED)) ;
			Log.i("TAG",s + " : " + String.valueOf(i));
			map = new HashMap<String, String>();
			map.put("category", s);
			map.put("percent","   "+ String.valueOf(i) + " %");
			myArrList.add(map);
		}



		cursor.close();




		SimpleAdapter adapter = new SimpleAdapter(this, myArrList, R.layout.simpleadapter_list_item,
				new String[] {"category", "percent"},
				new int[] {R.id.textView10, R.id.textView20});
		menu_list.setAdapter(adapter);*/
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				R.layout.my_sinple_list_item, getResources().getStringArray(R.array.category_menu));
		menu_list.setAdapter(adapter);

		menu_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View itemClicked, int position, long id) {
				Intent intent = new Intent(MainActivity.this, CardTestActivity.class);
				TypedArray ar = getResources().obtainTypedArray(R.array.ids);
				int len = ar.length();
				int[] resIds = new int[len];
				for (int i = 0; i < len; i++)
					resIds[i] = ar.getResourceId(i, 0);
				ar.recycle();
				intent.putExtra("id_icon", resIds[3 * (int) id]);
				intent.putExtra("id_de", resIds[3 * (int) id + 1]);
				intent.putExtra("id_loc", resIds[3 * (int) id + 2]);
				intent.putExtra("id", (int) id);
				MainActivity.this.startActivity(intent);
			}
		});

	}

	/*@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Toast toast = Toast.makeText(getApplicationContext(),
				"Программа предназначенная для тренировки словарного запаса.\nИнструкция :\nПосле показа картинки, пользователю " +
						"предлагается 2 варианта \'Я прав\' или \'Я не прав\'. \nВсе права принадлежать Aleks-Z. Copyright,2013. ", Toast.LENGTH_LONG);
		toast.setGravity(Gravity.CENTER, 0, 0);
		*//*LinearLayout toastView = (LinearLayout) toast.getView();
		ImageView imageCat = new ImageView(getApplicationContext());
		imageCat.setImageResource(R.drawable.krauser_san);
		toastView.addView(imageCat, 0);*//*
		toast.show();
		return true;
	}*/



}
